$(document).ready(function() {
	
	
	/***************************
	 ** Drop Down Mobile Menu **
	 ***************************/
	
	$(".burger-nav").click(function() {
		$(".site-navigation .main-nav").toggleClass("open");
	});

	 $(".main-nav li").click(function() {
		$('.dropdown-content').toggleClass("open");	
	 });
	 
	 
	/****************
	 ** Date Picker *
	 ****************/
	
	
	$(function() {
		$( ".date" ).datepicker();
	});
	
	
	/****************
	 ** active nav **
	 ****************/
	
	// 1. Grabs the URL from the browser.
	
	//var href = location.href;
	
	// 2. RegExp on URL to extract last part excluding slashes e.g /home/ will return home. 
	
	//var hrefstr = href.match(/([^\/]*)\/*$/)[1];
	//console.log(hrefstr);
	
	// 3. Inputting that into the a tag selector with the href attribute and adding a class of active.
	
	//$('a[href="'+hrefstr+'"]').addClass("active");
	 
	/*******************
	 ** Scroll To Top **
	 *******************/
	
    $(window).scroll(function() {
        if ($(this).scrollTop() >= 50) { 
            $('#return-to-top').fadeIn(1000); 
        } else {
            $('#return-to-top').fadeOut(1000);
        }
    });
	
    $('#return-to-top').click(function() { 
        $('body,html').animate({
            scrollTop: 0 
        }, 500);
    });
	
	/*******************
	 ** jQuery UI C/R **
	 *******************/ 
	
    $(function() {
        $(".checkradio input").checkboxradio({});
    });
	
	
	/******************
	 ** Image Slider **
	 ******************/ 
	
    $('.slide').slick({
        arrows: false,
        dots: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 4000,
    });
	
	/************************************
	 ** Code Snippets - Delete In Full **
	 ************************************/ 
	
    $('pre').hide();
    $('.button-toggle').on('click touch', function() {
        $(this).next('pre').toggle('fast');
    });
	
    $('.button-toggle-d').on('click touch', function() {
        $('.pre-d').toggle(500);
        $('.pre-h').toggle(false);
        $('.pre-f').toggle(false);
    });
	
    $('.button-toggle-h').on('click touch', function() {
        $('.pre-h').toggle(500);
        $('.pre-d').toggle(false);
        $('.pre-f').toggle(false);
    });
	
    $('.button-toggle-f').on('click touch', function() {
        $('.pre-f').toggle(500);
        $('.pre-h').toggle(false);
        $('.pre-d').toggle(false);
    });
	
	/***************
	 ** Accordion **
	 ***************/  
	
    $('div.panel').hide();
    $("button.accordion").on('click touch ', function() {
        $(this).next().toggle('fast');
    });
});